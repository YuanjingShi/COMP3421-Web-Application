<?php
$username = "yourmySQLusername";
$password = "yourmySQLpassword";
$dbase = "yourmySQLdatabasename";
?>