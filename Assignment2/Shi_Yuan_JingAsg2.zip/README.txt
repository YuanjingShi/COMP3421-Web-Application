Pong Hau Qi Game

This is all you need to know:

1. First open up the login page. If you already got a username(see all in the user.txt), you could just login with your existing geo-information and win count. If not, system would just create a new user for you in the “user.txt”.

2. After you log into the system, you will be able to see a page with a header reminding you of the numbers of players waiting for you. And all the users, who used to play the game and their win times on a map. Of course if you see another user awaiting you can just click pairing and you will get into the game.

3. Once you and your opponent both get into the game. Let the game begin! Both of you could make the first move, as the first player. And the other would be the second player.

4. There is no time limitations on this version since you need to click update every time you finish your move and once your opponent finish his/her turn, the last move would automatically be made on your game board unless you forget to click the “update” button

5. If any side of the game finishes its last move and win, they could immediately get a winning message. However this winning message would only be displayed if the loser’s side click the “update” button.

6. Do remember to click “start” button at the beginning of the game or you would not be able to make any move.

7. Do remember to click “update” at least one time if you want to check your opponent’s situation.

 Hope you will enjoy the game and strictly follow the rules or you may not be able to discover the whole functionality of this game.

 Student Name: Yuanjing Shi
 Student ID: 13104584d
