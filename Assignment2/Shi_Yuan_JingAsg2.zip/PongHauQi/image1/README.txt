Pong Hau Qi Game

This is all you need to know:

1. Once you open the game(on a web browser of course e.g. Chrome, Safari), you
will see the whole chess board has been already set up.

2. Start button: Begin the game or resume the game from a pause. Notice that
every time you resume a game, the timer would reset to 20, which intentionally
give you more time to take your move.

3. Pause button: pause the game in your turn and so do the timer.

4. Restart button: reload the whole page and restart the game.

5. You got a timer just above the chess board so beware of your left time.

5. Rule:

    a. The AI would automatically take her move so just focus on your own
    business.

    b. Your could only move your pieces(green ones) validly, which means that
    pieces could be only moved to its neighbor empty chess position.

    c. Moves on occupied positions or invalid moves on non-neighbor chess
    positions would trigger the warn message and reset the game.

    d. Once you make the key move to block all your opponent's move, you win
    with a win message on the screen. Timer pauses and click the "restart"
    button if you want play some more.

    e. Do remember to click the "start" button every time you want to begin the
    game or you premature move would be invalid.

 Hope you will enjoy the game (since this ai is not ai ai, like, at all).

 Student Name: Yuanjing Shi
 Student ID: 13104584d
